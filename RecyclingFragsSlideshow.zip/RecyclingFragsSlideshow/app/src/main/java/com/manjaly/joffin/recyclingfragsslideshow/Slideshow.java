package com.manjaly.joffin.recyclingfragsslideshow;

/**
 * Created by Joffin on 11/21/17.
 */

import java.util.ArrayList;
import java.util.List;

public class Slideshow {

    private List<String> pics;
    private int count;
    private String label;

    public Slideshow(){
        this.pics = new ArrayList<String>();
        this.count = 0;
    }
    public boolean add(String s){
        this.pics.add(s);
        this.count++;
        return false;
    }
    public int size(){
        return this.count;
    }

    public boolean isEmpty(){
        return (this.pics.isEmpty());
    }
    public String get(int i){
        return this.pics.get(i);
    }

    public List<String> getList(){
        return this.pics;
    }
    public String getLabel(){return (this.label);}
    public void setLabel(String s){this.label = s;}

}