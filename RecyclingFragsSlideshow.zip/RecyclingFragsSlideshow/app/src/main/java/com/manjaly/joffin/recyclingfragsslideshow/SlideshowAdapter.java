package com.manjaly.joffin.recyclingfragsslideshow;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Joffin on 11/28/17.
 */

public class SlideshowAdapter extends RecyclerView.Adapter<SlideshowAdapter.MyViewHolder>{

    private List<Slideshow> slideshowList;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView label;

        public MyViewHolder(View view){
            super(view);
            label = (TextView) view.findViewById(R.id.label);

        }

    }


    public SlideshowAdapter(List<Slideshow> slideshowList) { this.slideshowList = slideshowList;}

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Slideshow slideshow = slideshowList.get(position);
        holder.label.setText(slideshow.getLabel());
    }

    @Override
    public int getItemCount() { return slideshowList.size();}

}
