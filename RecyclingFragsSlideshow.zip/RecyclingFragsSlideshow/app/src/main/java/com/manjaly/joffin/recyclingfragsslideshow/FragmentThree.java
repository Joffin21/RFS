package com.manjaly.joffin.recyclingfragsslideshow;

/**
 * Created by Joffin on 11/21/17.
 */


/* ------------------------*/
/*    FILE VERSION 6.0     */
/* ------------------------*/

import android.content.Context;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class FragmentThree extends Fragment implements View.OnClickListener{

    private View mRootView;
    private FragmentThreeInterface mCallback;
    private TextView mTextView;
    private Button mButton;
    private ImageView mImageView;

    private int mClickCounter = 0;

    public FragmentThree() {
    }

    public static FragmentThree newInstance() {
        FragmentThree fragment = new FragmentThree();
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mCallback = (FragmentThreeInterface) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement FragmentThreeInterface");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_three, container, false);
        mTextView = (TextView) mRootView.findViewById(R.id.tv_03);
        mTextView.setText("This is a Fragment 3");

        //mButton = (Button) mRootView.findViewById(R.id.button1);
        //mButton.setOnClickListener(this);

        mImageView = (ImageView) mRootView.findViewById(R.id.ImgV1);
        mImageView.setOnClickListener(this);
        return mRootView;
    }

    @Override
    public void onClick(View v) {

//        mClickCounter++;
//        mTextView.setText(mClickCounter+"");
//        mCallback.updateCounter(mClickCounter);
        ImageView mImg = (ImageView)v;
        if(v == mRootView.findViewById(R.id.ImgV1)){
            mTextView = (TextView) mRootView.findViewById(R.id.tv_03);
            mCallback.cycle(mImg);
        }
    }

    public interface FragmentThreeInterface {
        void cycle(ImageView v);
    }
}