package com.manjaly.joffin.recyclingfragsslideshow;

/**
 * Created by Joffin on 11/21/17.
 */

/* ------------------------*/
/*    FILE VERSION 6.0     */
/* ------------------------*/

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FragmentTwo extends Fragment implements View.OnClickListener{

    private View mRootView;
    private FragmentTwoInterface mCallback;

    private List<Slideshow> slideshowList = new ArrayList<>();
    private RecyclerView recyclerView;
    private SlideshowAdapter adapter;

    private SlideshowContainer mContainer;
    private final String INTERNAL_STORAGE_FILE = "pics.json";
    private Context mContext;

    private TextView mTextView;
    private Button mButton;
    private EditText mEditText;

    private int mClickCounter = 0;

    public FragmentTwo() {
    }

    public static FragmentTwo newInstance() {
        FragmentTwo fragment = new FragmentTwo();
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mCallback = (FragmentTwoInterface) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement FragmentTwoInterface");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_two, container, false);
        //mTextView = (TextView) mRootView.findViewById(R.id.tv_02);
        //mTextView.setText("This is a Fragment 2");

        //mButton = (Button) mRootView.findViewById(R.id.button1);
        //mButton.setOnClickListener(this);
        //mEditText = (EditText) mRootView.findViewById(R.id.editText);

        recyclerView = (RecyclerView) mRootView.findViewById(R.id.recycling);

        adapter = new SlideshowAdapter(slideshowList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        //prepareMovieData();

        return mRootView;
    }

    public void prepareMovieData(){
        Gson gson = new Gson();
        mContainer = gson.fromJson(readInternalFile(),SlideshowContainer.class);
        for(int i = 0;i<mContainer.size()-1;i++){
            slideshowList.add(mContainer.get(i));
        }
        adapter.notifyDataSetChanged();


    }

    @Override
    public void onClick(View v) {
//        mClickCounter++;
//        mTextView.setText(mClickCounter+"");
//        mCallback.updateCounter(mClickCounter);
        //mEditText = (EditText) mRootView.findViewById(R.id.editText);
        //String s = mEditText.getText()+"";
        //if(!s.equals("")){
        //    mCallback.set(mEditText.getText()+"");
        //}
    }

    public interface FragmentTwoInterface {
        void set(String s);
//        void prepareMovieData();
    }

    public String readInternalFile() {
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        try {
            FileInputStream fis;
            fis = mContext.openFileInput(INTERNAL_STORAGE_FILE);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) != -1) {
                result.write(buffer, 0, length);
            }
            return result.toString("UTF-8");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }
}
