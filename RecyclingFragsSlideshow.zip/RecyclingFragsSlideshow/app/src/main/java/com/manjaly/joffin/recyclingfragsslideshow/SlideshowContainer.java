package com.manjaly.joffin.recyclingfragsslideshow;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Joffin on 11/28/17.
 */

public class SlideshowContainer {
    private List<Slideshow> slideshows;
    private int size;

    public SlideshowContainer(){
        this.slideshows = new ArrayList<Slideshow>();
        this.size = 0;
    }
    public int size(){
        size = 0;
        for(int i = 0; i < slideshows.size();i++){
            size++;
        }
        return size;
    }
    public List<Slideshow> getList(){return slideshows;}
    public Slideshow get(int i){ return this.slideshows.get(i);}

}
