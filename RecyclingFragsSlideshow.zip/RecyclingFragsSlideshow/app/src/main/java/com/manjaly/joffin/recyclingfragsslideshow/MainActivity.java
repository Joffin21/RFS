package com.manjaly.joffin.recyclingfragsslideshow;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements FragmentOne.FragmentOneInterface, FragmentTwo.FragmentTwoInterface, FragmentThree.FragmentThreeInterface{

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;
    private int count;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    String mCurrentPhotoPath;
    private Slideshow slideshow;
    private SlideshowContainer mContainer;
    private final String INTERNAL_STORAGE_FILE = "pics.json";
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        slideshow = new Slideshow();

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

    }
//------------------------------------------------INTERFACE METHODS-------------------------------------------//
    @Override
    public void dispatchTakePictureIntent(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePictureIntent.resolveActivity(getPackageManager()) != null){
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Gson gson = new Gson();
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            mCurrentPhotoPath = writeInternalImageFile(imageBitmap);
            //ImageView mImageView = (ImageView)findViewById(R.id.ImgV1);
            slideshow.add(mCurrentPhotoPath);
            writeInternalFile(gson.toJson(slideshow));
        }
    }


    @Override
    public void set(String s){
        Gson gson = new Gson();
        slideshow = new JSONReader(this).readFile();
        if(slideshow != null) {
            slideshow.setLabel(s);
            writeInternalFile(gson.toJson(slideshow));
        }
    }

    @Override
    public void cycle(ImageView v){
        if (!slideshow.isEmpty()) {
            Log.i("list", slideshow.size() + "");
            if (count == slideshow.size() - 1) {
                count = -1;
            }
            count++;
            String name = slideshow.get(count);
            v.setImageBitmap(readInternalImageFile(name));
            final TextView textView = (TextView) findViewById(R.id.tv_03);
            textView.setText(slideshow.getLabel());
        }
    }

//    @Override
//    public void prepareMovieData(){
//        Gson gson = new Gson();
//        mContainer = gson.fromJson(readInternalFile(),SlideshowContainer.class);
//    }

//---------------------------------------------------SECTIONS PAGER ADAPTER----------------------------------------------------------//

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }


        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0 :
                    return FragmentOne.newInstance();
                case 1 :
                    return FragmentTwo.newInstance();
                case 2 :
                    return FragmentThree.newInstance();
                default :
                    return null;
            }
        }

        @Override
        public int getCount() {
            // Show 3 total pages.
            return 3;
        }

    }

    //------------------------------------------------------------------STORAGE---------------------------------------------------------------------//
    private String writeInternalImageFile(Bitmap b){
        //Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format((new Date()));
        String imageFileName = "JPEG_" + timeStamp + "_";
        //slideshow.add(imageFileName);
        imageFileName = "Filename :\"" +imageFileName+"\"";
        Log.i("toJson",imageFileName);
        Context context = getApplicationContext();
        try{
            FileOutputStream fos;
            fos = context.openFileOutput(imageFileName, Context.MODE_PRIVATE);
            b.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            return imageFileName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Bitmap readInternalImageFile(String fname)
    {
        Context context = getApplicationContext();
        try{
            FileInputStream fis;
            fis = context.openFileInput(fname);
            return BitmapFactory.decodeStream(fis);
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }
        return null;
    }

    public void writeInternalFile(String s) {
        Context context = getApplicationContext();
        try {
            FileOutputStream fos;
            fos = context.openFileOutput(INTERNAL_STORAGE_FILE, Context.MODE_PRIVATE);
            fos.write(s.getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
