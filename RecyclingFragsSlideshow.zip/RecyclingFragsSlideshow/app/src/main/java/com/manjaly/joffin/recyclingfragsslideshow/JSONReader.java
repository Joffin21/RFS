package com.manjaly.joffin.recyclingfragsslideshow;

/**
 * Created by Joffin on 11/21/17.
 */

import android.content.Context;
import android.content.res.AssetManager;
import android.transition.Slide;
import android.util.Log;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;


public class JSONReader {
    private Context mContext;
    private Gson mGson;

    private static final String PICTURES_FILE = "pics.json";

    public JSONReader(Context c) {

        mGson = new GsonBuilder().create();
        mContext = c;
    }

    public Slideshow readFile() {
        String res = readInternalFile();
        Log.i("check", res);
        if (res != null) {
            return mGson.fromJson(res, Slideshow.class);
        } else {
            return new Slideshow();
        }
    }


    public String readInternalFile() {
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        try {
            FileInputStream fis;
            fis = mContext.openFileInput(PICTURES_FILE);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = fis.read(buffer)) != -1) {
                result.write(buffer, 0, length);
            }
            return result.toString("UTF-8");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }
}